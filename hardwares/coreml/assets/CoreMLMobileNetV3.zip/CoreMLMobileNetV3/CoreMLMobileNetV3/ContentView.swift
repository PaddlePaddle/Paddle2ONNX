//
//  ContentView.swift
//  CoreMLMobileNetV3
//
//  Created by Winston Fan on 19/3/22.
//

import SwiftUI

extension UIImage {
    public func resized(to target: CGSize) -> UIImage {
        let ratio = min(
            target.height / size.height, target.width / size.width
        )
        let new = CGSize(
            width: size.width * ratio, height: size.height * ratio
        )
        let renderer = UIGraphicsImageRenderer(size: new)
        return renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: new))
        }
    }
    
    func imageResized(to size: CGSize) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { _ in
            draw(in: CGRect(origin: .zero, size: size))
        }
    }
}

struct ContentView: View {
    @State private var image = UIImage()
    @State private var showSheet = false
    @State private var predictionResult: String = "Prediction result..."
    
//    let model = mbnetv3_labelled_op9()
    let model = GetMobileNetV3Model()
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage? {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(origin: .zero, size: newSize)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage
    }
    
    var body: some View {
        VStack {
                        
                        Image("paddlelogo")
                            .renderingMode(.original)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 350, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        Text("Paddle MobileNet V3 Demo")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color(#colorLiteral(red: 0.5647058824, green: 0.462745098, blue: 0.9058823529, alpha: 1)))
                        
                        Image(uiImage: self.image)
                          .resizable()
                          .cornerRadius(25)
                          .frame(width: 350, height: 500)
                        .background(Color.black.opacity(0.2).cornerRadius(25))
                          .aspectRatio(contentMode: .fill)
                          .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .strokeBorder(
                                    style: StrokeStyle(
                                            lineWidth: 2,
                                            dash: [15]
                                            )
                                        )
                                        .foregroundColor(Color(#colorLiteral(red: 0.5647058824, green: 0.462745098, blue: 0.9058823529, alpha: 1)))
                            )
                          

                        Text(predictionResult)
                            .padding(15)
                            .font(.headline)
                            .frame(width: 350, height: 70, alignment: .leading)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .foregroundColor(Color.black.opacity(0.7))
                            .background(Color.gray.opacity(0.2).cornerRadius(25))
                            
                        HStack(spacing:0) {
                            VStack {
                                Text("Pick up a photo")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 50)
                                    .background(LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.262745098, green: 0.0862745098, blue: 0.8588235294, alpha: 1)), Color(#colorLiteral(red: 0.5647058824, green: 0.462745098, blue: 0.9058823529, alpha: 1))]), startPoint: .top, endPoint: .bottom))
                                    .cornerRadius(16)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .onTapGesture {
                                           showSheet = true
                                         }
                            }
                                .frame(minWidth: 0, maxWidth: .infinity)
                            
                            VStack {
                                Button("Predict") {
                                    do {
                                        let model = GetMobileNetV3Model()
                                        let inputs: mbnetv3_0913Input = try .init(inputsWith: self.image.cgImage!)
                                        let result: mbnetv3_0913Output = try! model.prediction(input: inputs)
                                            
                                        self.predictionResult = result.classLabel
                                    } catch {
                                        return
                                    }
                                }
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.262745098, green: 0.0862745098, blue: 0.8588235294, alpha: 1)), Color(#colorLiteral(red: 0.5647058824, green: 0.462745098, blue: 0.9058823529, alpha: 1))]), startPoint: .top, endPoint: .bottom))
                                .cornerRadius(16)
                                .foregroundColor(.white)
                                .padding(.horizontal, 20)
                            }
                                .frame(minWidth: 0, maxWidth: .infinity)
                            
                        }
                    }
            .padding(.horizontal, 20)
            .sheet(isPresented: $showSheet) {
                            // Pick an image from the photo library:
                        ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)

                            //  If you wish to take a photo from camera instead:
                            // ImagePicker(sourceType: .camera, selectedImage: self.$image)
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
