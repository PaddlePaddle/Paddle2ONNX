//
//  Predictor.swift
//  CoreMLMobileNetV3
//
//  Created by Winston Fan on 19/3/22.
//

import Foundation
import CoreML

func GetMobileNetV3Model() -> mbnetv3_0913 {
    let model: mbnetv3_0913 = {
        do {
            let config = MLModelConfiguration()
            return try mbnetv3_0913(configuration: config)
        } catch {
            print(error)
            fatalError("Could not create MobileNetV3")
        }
    }()
    
    return model
}

