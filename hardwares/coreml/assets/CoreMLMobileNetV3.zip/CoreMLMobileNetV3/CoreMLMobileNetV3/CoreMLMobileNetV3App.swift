//
//  CoreMLMobileNetV3App.swift
//  CoreMLMobileNetV3
//
//  Created by Winston Fan on 19/3/22.
//

import SwiftUI

@main
struct CoreMLMobileNetV3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
